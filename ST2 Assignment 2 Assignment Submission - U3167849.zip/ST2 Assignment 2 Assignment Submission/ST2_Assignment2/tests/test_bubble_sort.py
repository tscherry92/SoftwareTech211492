import unittest


def bubble_sort(arr):
    arr = arr.copy()
    n = len(arr)

    for i in range(n):
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

    return arr


class TestBubbleSort(unittest.TestCase):

    def test_unsorted_list(self):
        print("\nRunning test: unsorted list")
        data = [5, 2, 8, 1, 3]
        result = bubble_sort(data)
        print(f"Input: {data} → Output: {result}")
        self.assertEqual(result, [1, 2, 3, 5, 8])

    def test_already_sorted_list(self):
        print("\nRunning test: already sorted list")
        data = [1, 2, 3, 4, 5]
        result = bubble_sort(data)
        print(f"Input: {data} → Output: {result}")
        self.assertEqual(result, [1, 2, 3, 4, 5])

    def test_reverse_sorted_list(self):
        print("\nRunning test: reverse sorted list")
        data = [5, 4, 3, 2, 1]
        result = bubble_sort(data)
        print(f"Input: {data} → Output: {result}")
        self.assertEqual(result, [1, 2, 3, 4, 5])


if __name__ == "__main__":
    unittest.main(verbosity=2)