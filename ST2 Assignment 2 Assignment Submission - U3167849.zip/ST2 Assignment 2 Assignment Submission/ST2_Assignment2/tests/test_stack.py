import unittest


class TestStack(unittest.TestCase):

    def test_stack_push(self):
        print("\nRunning test: stack push")

        stack = []
        print(f"Before push → {stack}")

        stack.append(1)

        print(f"After push  → {stack}")

        self.assertEqual(stack, [1])

    def test_stack_pop(self):
        print("\nRunning test: stack pop")

        stack = [1, 2, 3]
        print(f"Before pop → {stack}")

        value = stack.pop()

        print(f"Popped value → {value}")
        print(f"After pop   → {stack}")

        self.assertEqual(value, 3)
        self.assertEqual(stack, [1, 2])

    def test_stack_empty_after_pop(self):
        print("\nRunning test: stack becomes empty")

        stack = [1]
        print(f"Before pop → {stack}")

        stack.pop()

        print(f"After pop  → {stack}")

        self.assertEqual(stack, [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
    