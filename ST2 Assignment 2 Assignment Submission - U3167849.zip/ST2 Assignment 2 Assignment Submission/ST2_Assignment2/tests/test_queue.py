import unittest
from modules.data_structures import enqueue, dequeue


class TestQueue(unittest.TestCase):

    def test_enqueue(self):
        print("\nRunning test: enqueue operation")

        state = {
            "queue": [],
            "queue_counter": 1
        }

        print(f"Before enqueue → {state['queue']}")
        enqueue(state)
        print(f"After enqueue  → {state['queue']}")

        self.assertEqual(state["queue"], [1])

    def test_dequeue(self):
        print("\nRunning test: dequeue operation")

        state = {
            "queue": [1, 2, 3],
            "queue_counter": 4
        }

        print(f"Before dequeue → {state['queue']}")
        dequeue(state)
        print(f"After dequeue  → {state['queue']}")

        self.assertEqual(state["queue"], [2, 3])

    def test_queue_fifo_order(self):
        print("\nRunning test: FIFO order check")

        state = {
            "queue": [],
            "queue_counter": 1
        }

        print(f"Start → {state['queue']}")

        enqueue(state)
        print(f"After enqueue 1 → {state['queue']}")

        enqueue(state)
        print(f"After enqueue 2 → {state['queue']}")

        enqueue(state)
        print(f"After enqueue 3 → {state['queue']}")

        dequeue(state)
        print(f"After dequeue   → {state['queue']}")

        self.assertEqual(state["queue"], [2, 3])


if __name__ == "__main__":
    unittest.main(verbosity=2)