# Re-defining the Red-Black Tree class after execution reset

class Node:
    """Represents a node in a Red-Black Tree."""
    def __init__(self, key, color="RED"):
        self.key = key
        self.color = color  # RED or BLACK
        self.left = None
        self.right = None
        self.parent = None

class RedBlackTree:
    """Implements a Red-Black Tree with balancing after insertions and deletions."""
    
    def __init__(self):
        self.NIL = Node(None, "BLACK")  # Sentinel NIL node
        self.root = self.NIL  # Root of the tree

    def insert(self, key):
        """Inserts a new key into the Red-Black Tree and balances it."""
        new_node = Node(key)
        new_node.left = self.NIL
        new_node.right = self.NIL

        parent = None
        current = self.root

        while current != self.NIL:
            parent = current
            if new_node.key < current.key:
                current = current.left
            else:
                current = current.right

        new_node.parent = parent

        if parent is None:  # Tree was empty
            self.root = new_node
        elif new_node.key < parent.key:
            parent.left = new_node
        else:
            parent.right = new_node

        new_node.color = "RED"  # New nodes are always inserted as RED
        self._fix_insert(new_node)  # Balance the tree

    def _fix_insert(self, node):
        """Fixes the Red-Black Tree after an insertion to maintain balance."""
        while node.parent and node.parent.color == "RED":
            grandparent = node.parent.parent

            if node.parent == grandparent.left:  # Parent is a left child
                uncle = grandparent.right

                if uncle.color == "RED":  # Case 1: Uncle is RED → Color flip
                    node.parent.color = "BLACK"
                    uncle.color = "BLACK"
                    grandparent.color = "RED"
                    node = grandparent
                else:  # Case 2 or 3: Uncle is BLACK
                    if node == node.parent.right:  # Case 2: Left-Right → Rotate Left
                        node = node.parent
                        self._rotate_left(node)

                    # Case 3: Left-Left → Rotate Right
                    node.parent.color = "BLACK"
                    grandparent.color = "RED"
                    self._rotate_right(grandparent)

            else:  # Parent is a right child (Mirror cases)
                uncle = grandparent.left

                if uncle.color == "RED":  # Case 1: Uncle is RED → Color flip
                    node.parent.color = "BLACK"
                    uncle.color = "BLACK"
                    grandparent.color = "RED"
                    node = grandparent
                else:  # Case 2 or 3: Uncle is BLACK
                    if node == node.parent.left:  # Case 2: Right-Left → Rotate Right
                        node = node.parent
                        self._rotate_right(node)

                    # Case 3: Right-Right → Rotate Left
                    node.parent.color = "BLACK"
                    grandparent.color = "RED"
                    self._rotate_left(grandparent)

        self.root.color = "BLACK"  # Ensure root is always BLACK

    def search(self, key):
        """Searches for a key in the Red-Black Tree."""
        current = self.root
        while current != self.NIL:
            if key == current.key:
                return current  # Node found
            elif key < current.key:
                current = current.left
            else:
                current = current.right
        return None  # Not found

    def _rotate_left(self, node):
        """Performs a left rotation on the given node."""
        right_child = node.right
        node.right = right_child.left

        if right_child.left != self.NIL:
            right_child.left.parent = node

        right_child.parent = node.parent

        if node.parent is None:  # Updating root
            self.root = right_child
        elif node == node.parent.left:
            node.parent.left = right_child
        else:
            node.parent.right = right_child

        right_child.left = node
        node.parent = right_child

    def _rotate_right(self, node):
        """Performs a right rotation on the given node."""
        left_child = node.left
        node.left = left_child.right

        if left_child.right != self.NIL:
            left_child.right.parent = node

        left_child.parent = node.parent

        if node.parent is None:  # Updating root
            self.root = left_child
        elif node == node.parent.right:
            node.parent.right = left_child
        else:
            node.parent.left = left_child

        left_child.right = node
        node.parent = left_child

    def inorder_traversal(self, node):
        """Performs an inorder traversal of the tree."""
        if node != self.NIL:
            self.inorder_traversal(node.left)
            print(f"{node.key} ({node.color})", end=" ")
            self.inorder_traversal(node.right)

    def print_tree(self):
        """Prints the tree structure in a readable format."""
        def print_helper(node, indent, last):
            if node != self.NIL:
                print(indent, "`- " if last else "|- ", f"{node.key} ({node.color})", sep="")
                indent += "   " if last else "|  "
                print_helper(node.left, indent, False)
                print_helper(node.right, indent, True)

        print_helper(self.root, "", True)

# ---------------------------- TEST CASE ----------------------------

# Create a Red-Black Tree instance
rbt = RedBlackTree()

# Insert values into Red-Black Tree
values_to_insert = [50, 30, 70, 20, 40, 60, 80, 25]
for val in values_to_insert:
    rbt.insert(val)

# Perform an inorder traversal to check tree balance
print("\nInorder Traversal After Insertions:")
rbt.inorder_traversal(rbt.root)

# Print the tree structure after insertions
print("\n\nRed-Black Tree Structure After Insertions:")
rbt.print_tree()

# Search for an existing and non-existing value
search_values = [25, 100]  # 25 is present, 100 is not
for key in search_values:
    found = rbt.search(key)
    print(f"\nSearching for {key}: {'Found' if found else 'Not Found'}")
