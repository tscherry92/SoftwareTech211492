class Graph:
    def __init__(self, directed=False, weighted=False):
        self.graph = {}
        self.weights = {}
        self.directed = directed
        self.weighted = weighted

    def add_vertex(self, vertex):
        if vertex not in self.graph:
            self.graph[vertex] = []

    def add_edge(self, vertex1, vertex2, weight=0):
        if vertex1 in self.graph and vertex2 in self.graph:
            if vertex2 not in self.graph[vertex1]:  # prevent duplicates
                self.graph[vertex1].append(vertex2)

            if self.weighted:
                self.weights[(vertex1, vertex2)] = weight

            if not self.directed:
                if vertex1 not in self.graph[vertex2]:
                    self.graph[vertex2].append(vertex1)

                if self.weighted:
                    self.weights[(vertex2, vertex1)] = weight
        else:
            print("One or both vertices not found in graph.")

    def print_graph(self):
        for vertex in self.graph:
            if self.weighted:
                edges = []
                for neighbor in self.graph[vertex]:
                    weight = self.weights.get((vertex, neighbor), None)
                    edges.append(f"{neighbor}({weight})")
                print(f"{vertex} -> {edges}")
            else:
                print(f"{vertex} -> {self.graph[vertex]}")

    def remove_edge(self, vertex1, vertex2):
        if vertex1 in self.graph and vertex2 in self.graph:
            if vertex2 in self.graph[vertex1]:
                self.graph[vertex1].remove(vertex2)
                if self.weighted:
                    self.weights.pop((vertex1, vertex2), None)

            if not self.directed:
                if vertex1 in self.graph[vertex2]:
                    self.graph[vertex2].remove(vertex1)
                    if self.weighted:
                        self.weights.pop((vertex2, vertex1), None)
        else:
            print("One or both vertices not found in graph.")

    def remove_vertex(self, vertex):
        if vertex in self.graph:
            # Remove incoming edges
            for v in self.graph:
                if vertex in self.graph[v]:
                    self.graph[v].remove(vertex)
                    if self.weighted:
                        self.weights.pop((v, vertex), None)

            # Remove outgoing edges
            if self.weighted:
                for neighbor in self.graph[vertex]:
                    self.weights.pop((vertex, neighbor), None)

            del self.graph[vertex]
        else:
            print("Vertex not found in graph.")

    # Teacher Girija provided this code to me at 2:30pm just before my computer lab:
        # Depth First Search algorithm
    def dfs(self, start_vertex):
        visited = set()
        stack = [start_vertex]

        while stack:
            vertex = stack.pop() # LIFO behavior
            if vertex not in visited:
                visited.add(vertex)
                print(vertex, end=' ')

            for neighbor in self.graph[vertex]:
                if neighbor not in visited:
                    stack.append(neighbor)
        print()
        return visited


    def cycle_dfs(self, current_vertex, visited: set, parent_vertex):
        visited.add(current_vertex)

        for neighbor in self.graph[current_vertex]:
            if neighbor not in visited:
                if self.cycle_dfs(neighbor, visited, current_vertex):
                    return True
            elif parent_vertex != neighbor:
                return True

        return False
        # Breadth First Search algorithm
    def bfs(self, start_vertex):
        visited = {start_vertex}
        queue = [start_vertex]

        while queue:
            vertex = queue.pop(0) # FIFO behavior
            print(vertex, end=' ')

            for neighbor in self.graph[vertex]:
                if neighbor not in visited:
                    queue.append(neighbor)
                    visited.add(neighbor)
        print()
        return visited