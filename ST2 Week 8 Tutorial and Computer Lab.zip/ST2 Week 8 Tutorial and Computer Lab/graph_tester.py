from graph import Graph

print("=== UNDIRECTED GRAPH TEST ===")
g = Graph()

# Add vertices
for v in ['A', 'B', 'C', 'D']:
    g.add_vertex(v)
print("After adding vertices:")
g.print_graph()
print()

# Add edges
g.add_edge('A', 'B')
g.add_edge('A', 'C')
g.add_edge('B', 'D')
print("After adding edges:")
g.print_graph()
print()

# Remove edge
g.remove_edge('A', 'B')
print("After removing edge A-B:")
g.print_graph()
print()

# Remove vertex
g.remove_vertex('C')
print("After removing vertex C:")
g.print_graph()
print()


print("=== DIRECTED GRAPH TEST ===")
g = Graph(directed=True)

# Add vertices
for v in ['A', 'B', 'C', 'D']:
    g.add_vertex(v)
print("After adding vertices:")
g.print_graph()
print()

# Add edges (direction matters now)
g.add_edge('A', 'B')
g.add_edge('B', 'C')
g.add_edge('C', 'D')
print("After adding edges:")
g.print_graph()
print()

# Remove edge
g.remove_edge('B', 'C')
print("After removing edge B -> C:")
g.print_graph()
print()

# Remove vertex
g.remove_vertex('D')
print("After removing vertex D:")
g.print_graph()
print()


print("=== WEIGHTED DIRECTED GRAPH TEST ===")
g = Graph(directed=True, weighted=True)

# Add vertices
for v in ['A', 'B', 'C', 'D']:
    g.add_vertex(v)

# Add weighted edges
g.add_edge('A', 'B', 10)
g.add_edge('A', 'C', 20)
g.add_edge('C', 'D', 30)

print("Weighted graph:")
g.print_graph()
print()

# BFS on the graph from Activity 1
print("BFS starting from vertex 'A':")
visited_bfs = g.bfs('A')
print("Visited vertices in BFS order:", visited_bfs)
