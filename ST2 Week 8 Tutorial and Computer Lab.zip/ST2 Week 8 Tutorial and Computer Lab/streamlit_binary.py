import streamlit as st
import time
import graphviz

# ---------------------------- BST Node & Class ----------------------------
class Node:
    """Class representing a single node in the Binary Search Tree."""
    def __init__(self, key):
        self.val = key
        self.left = None
        self.right = None

class BST:
    """Binary Search Tree class implementing insert, search, delete, and traversal methods."""
    def __init__(self):
        self.root = None
        self.traversal_path = []  # Stores traversal steps

    def insert(self, key):
        """Insert a new node into the BST."""
        if self.root is None:
            self.root = Node(key)
        else:
            self._insert_recursive(self.root, key)

    def _insert_recursive(self, root, key):
        """Helper method for inserting recursively."""
        if key < root.val:
            if root.left is None:
                root.left = Node(key)
            else:
                self._insert_recursive(root.left, key)
        else:
            if root.right is None:
                root.right = Node(key)
            else:
                self._insert_recursive(root.right, key)

    def search(self, key):
        """Search for a key in BST and highlight search path."""
        self.traversal_path = []
        return self._search_recursive(self.root, key)

    def _search_recursive(self, root, key):
        """Recursive search with path highlighting."""
        if root is None:
            return False
        self.traversal_path.append(root.val)
        self.display_tree(highlight_nodes=self.traversal_path)
        time.sleep(1)
        if root.val == key:
            return True
        if key < root.val:
            return self._search_recursive(root.left, key)
        return self._search_recursive(root.right, key)

    def delete(self, key):
        """Delete a node from BST."""
        self.traversal_path = []
        self.root = self._delete_recursive(self.root, key)

    def _delete_recursive(self, root, key):
        """Recursive delete method with path highlighting."""
        if root is None:
            return root

        self.traversal_path.append(root.val)
        self.display_tree(highlight_nodes=self.traversal_path)
        time.sleep(1)

        if key < root.val:
            root.left = self._delete_recursive(root.left, key)
        elif key > root.val:
            root.right = self._delete_recursive(root.right, key)
        else:
            if root.left is None:
                return root.right
            elif root.right is None:
                return root.left
            temp = self._minValueNode(root.right)
            root.val = temp.val
            root.right = self._delete_recursive(root.right, temp.val)

        return root

    def _minValueNode(self, node):
        """Helper function to find the smallest value node in right subtree."""
        current = node
        while current.left:
            current = current.left
        return current

    def inorder(self):
        """Perform an inorder traversal and animate it."""
        self.traversal_path = []
        self._inorder_recursive(self.root)

    def _inorder_recursive(self, root):
        """Helper method for inorder traversal animation."""
        if root:
            self._inorder_recursive(root.left)
            self.traversal_path.append(root.val)
            self.display_tree(highlight_nodes=self.traversal_path)
            time.sleep(1)
            self._inorder_recursive(root.right)

    def preorder(self):
        """Perform a preorder traversal and animate it."""
        self.traversal_path = []
        self._preorder_recursive(self.root)

    def _preorder_recursive(self, root):
        """Helper method for preorder traversal animation."""
        if root:
            self.traversal_path.append(root.val)
            self.display_tree(highlight_nodes=self.traversal_path)
            time.sleep(1)
            self._preorder_recursive(root.left)
            self._preorder_recursive(root.right)

    def postorder(self):
        """Perform a postorder traversal and animate it."""
        self.traversal_path = []
        self._postorder_recursive(self.root)

    def _postorder_recursive(self, root):
        """Helper method for postorder traversal animation."""
        if root:
            self._postorder_recursive(root.left)
            self._postorder_recursive(root.right)
            self.traversal_path.append(root.val)
            self.display_tree(highlight_nodes=self.traversal_path)
            time.sleep(1)

    def display_tree(self, highlight_nodes=[]):
        """Visualize the tree using Graphviz."""
        dot = graphviz.Digraph()
        if self.root:
            self._add_edges(dot, self.root, highlight_nodes)
        st.graphviz_chart(dot)

    def _add_edges(self, dot, node, highlight_nodes):
        """Recursive function to add edges and nodes to Graphviz."""
        color = "red" if node.val in highlight_nodes else "black"
        dot.node(str(node.val), color=color)
        if node.left:
            dot.edge(str(node.val), str(node.left.val))
            self._add_edges(dot, node.left, highlight_nodes)
        if node.right:
            dot.edge(str(node.val), str(node.right.val))
            self._add_edges(dot, node.right, highlight_nodes)


# ---------------------------- Streamlit UI ----------------------------
st.title("🌳 Binary Search Tree Visualization with Animations")
st.write("Real-time BST visualization with Insert, Delete, Search, and Tree Traversals.")

# Initialize BST in Streamlit session state
if "bst" not in st.session_state:
    st.session_state.bst = BST()

bst = st.session_state.bst

operation = st.radio("Choose an Operation:", ["Insert", "Delete", "Search", "Inorder Traversal", "Preorder Traversal", "Postorder Traversal"])

if operation in ["Insert", "Delete", "Search"]:
    value = st.number_input(f"Enter value to {operation.lower()}:", min_value=0, max_value=999, step=1)

if st.button("Execute Operation"):
    if operation == "Insert":
        bst.insert(value)
    elif operation == "Delete":
        bst.delete(value)
    elif operation == "Search":
        found = bst.search(value)
        st.success(f"{value} {'found' if found else 'not found'} in the tree.")
    elif operation == "Inorder Traversal":
        bst.inorder()
    elif operation == "Preorder Traversal":
        bst.preorder()
    elif operation == "Postorder Traversal":
        bst.postorder()

st.write("### 📌 Current Binary Search Tree:")
bst.display_tree()




