import random
import timeit


# TASK 1: RECURSION VS ITERATION

# Recursive implementations

def sum_recursive(n):
    if n == 1:
        return 1
    return n + sum_recursive(n - 1)

def fibonacci_recursive(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1
    return fibonacci_recursive(n - 1) + fibonacci_recursive(n - 2)

def factorial_recursive(n):
    if n == 0:
        return 1
    return n * factorial_recursive(n - 1)

# Iterative implementations
def sum_iterative(n):
    total = 0
    for i in range(1, n + 1):
        total += i
    return total

def fibonacci_iterative(n):
    if n <= 0:
        return 0
    elif n == 1:
        return 1

    a, b = 0, 1
    for _ in range(2, n + 1):
        a, b = b, a + b
    return b

def factorial_iterative(n):
    result = 1
    for i in range(1, n + 1):
        result *= i
    return result

# TEST VALUES 
sum_values = [10, 50, 70]
fib_values = [5, 10, 20, 30]  # keep small for recursion!
fact_values = [5, 10, 20]

print("\n===== RESULTS =====")

# SUM TESTS
print("\n--- SUM ---")
for n in sum_values:
    print(f"\nn = {n}")
    print("Recursive:", sum_recursive(n))
    print("Iterative:", sum_iterative(n))

# FIBONACCI TESTS
print("\n--- FIBONACCI ---")
for n in fib_values:
    print(f"\nn = {n}")
    print("Recursive:", fibonacci_recursive(n))
    print("Iterative:", fibonacci_iterative(n))

# FACTORIAL TESTS
print("\n--- FACTORIAL ---")
for n in fact_values:
    print(f"\nn = {n}")
    print("Recursive:", factorial_recursive(n))
    print("Iterative:", factorial_iterative(n))


# BENCHMARKING
print("\n===== BENCHMARKS =====")

# Factorial benchmark
for n in [10, 20]:
    rec_time = timeit.timeit(lambda: factorial_recursive(n), number=1000)
    itr_time = timeit.timeit(lambda: factorial_iterative(n), number=1000)

    print(f"\nFactorial n={n}")
    print("Recursive:", rec_time)
    print("Iterative:", itr_time)

# Fibonacci benchmark
for n in [10, 20, 30]:
    rec_time = timeit.timeit(lambda: fibonacci_recursive(n), number=10)
    itr_time = timeit.timeit(lambda: fibonacci_iterative(n), number=1000)

    print(f"\nFibonacci n={n}")
    print("Recursive:", rec_time)
    print("Iterative:", itr_time)

# Sum benchmark
for n in [50, 100]:
    rec_time = timeit.timeit(lambda: sum_recursive(n), number=100)
    itr_time = timeit.timeit(lambda: sum_iterative(n), number=100)

    print(f"\nSum n={n}")
    print("Recursive:", rec_time)
    print("Iterative:", itr_time)

# Additional: Time comparison for sum_values to see difference clearly
print("\n===== SUM TIME COMPARISON =====")
for n in sum_values:
    rec_time = timeit.timeit(lambda: sum_recursive(n), number=1000)
    itr_time = timeit.timeit(lambda: sum_iterative(n), number=1000)
    print(f"\nn = {n}")
    print(f"Recursive time: {rec_time:.6f} sec")
    print(f"Iterative time: {itr_time:.6f} sec")

# Conclusion
# Iterative was much faster and more memory-efficient than the recursive code.
# Recursive is easier to understand and implement for problems with natural recursion.
# Fibonacci recursion was a lot slower due to repeated calculations (exponential time complexity),
# while the iterative version runs in linear time.


# TASK 2: MERGE SORT VS INSERTION SORT


def merge_sort(array):
    if len(array) <= 1:
        return array

    mid = len(array) // 2
    left = merge_sort(array[:mid])
    right = merge_sort(array[mid:])

    return merge(left, right)

def merge(left, right):
    merged = []
    i = j = 0

    while i < len(left) and j < len(right):
        if left[i] < right[j]:
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1

    merged.extend(left[i:])
    merged.extend(right[j:])
    return merged

def insertion_sort(arr):
    for i in range(1, len(arr)):
        current = arr[i]
        j = i - 1

        while j >= 0 and current < arr[j]:
            arr[j + 1] = arr[j]
            j -= 1

        arr[j + 1] = current

    return arr


#Testing different sizes
sizes = [10, 100, 1000]

print("\nTASK 2 RESULTS")

for size in sizes:
    test_list = [random.randint(1, 1000) for _ in range(size)]

    insertion_time = timeit.timeit(lambda: insertion_sort(test_list[:]), number=10)
    merge_time = timeit.timeit(lambda: merge_sort(test_list[:]), number=10)

    print(f"\nSize: {size}")
    print(f"Insertion Sort: {insertion_time:.6f}")
    print(f"Merge Sort: {merge_time:.6f}")


# Conclusion
# Merge Sort performed better for the larger datasets due to its O(n log n) time complexity.
# Insertion Sort was inefficient for large datasets.
# Insertion Sort performed well on the smaller datasets due to its low overhead.



# TASK 3: TOWER OF HANOI


move_count = 0

def moveDisks(n, fromTower, toTower, auxTower):
    global move_count

    if n == 1:
        print("Move disk 1 from", fromTower, "to", toTower)
        move_count += 1
    else:
        moveDisks(n - 1, fromTower, auxTower, toTower)
        print("Move disk", n, "from", fromTower, "to", toTower)
        move_count += 1
        moveDisks(n - 1, auxTower, toTower, fromTower)


print("\nTASK 3 RESULTS")

for disks in [3, 4]:
    move_count = 0
    print(f"\n--- {disks} disks ---")
    moveDisks(disks, 'A', 'B', 'C')
    print("Total moves:", move_count)


#With user input

# Ask the user for the number of disks
numberOfDisks = input("How many Disks would you like to use? ")
numberOfDisksInteger = int(numberOfDisks)

# Run the Tower of Hanoi for the chosen number of disks
for disks in [numberOfDisksInteger]:
    move_count = 0
    print(f"\n--- {disks} disks ---")
    moveDisks(disks, 'A', 'B', 'C')
    print("Total moves:", move_count)

# Conclusion
# The number of moves required follows the formula 2^n - 1.
# This demonstrates exponential growth in recursive algorithms.




# TASK 4: KOCH SNOWFLAKE (FRACTAL)


import turtle

def koch_curve(t, order, size):
    if order == 0:
        t.forward(size)
    else:
        size /= 3
        koch_curve(t, order - 1, size)
        t.left(60)
        koch_curve(t, order - 1, size)
        t.right(120)
        koch_curve(t, order - 1, size)
        t.left(60)
        koch_curve(t, order - 1, size)

def koch_snowflake(order, size):
    t = turtle.Turtle()
    t.speed(0)

    for _ in range(3):
        koch_curve(t, order, size)
        t.right(120)

    turtle.done()


# 
    koch_snowflake(order=3, size=300)


# Conclusion
# The Koch Snowflake fractal demonstrates recursion by repeatedly applying
# the same transformation to smaller segments.
# As the order increases, the complexity and detail of the shape increases.
# This helps to show how recursion can model self-similar structures found in mathematics and nature.

#sierpinski_triangle.py
from tkinter import * # Import tkinter

class SierpinskiTriangle:
    def __init__(self):
        window = Tk() # Create a window
        window.title("Sierpinski Triangle") # Set a title

        self.width = 200
        self.height = 200
        self.canvas = Canvas(window,
            width = self.width, height = self.height)
        self.canvas.pack()

        # Add a label, an entry, and a button to frame1
        frame1 = Frame(window) # Create and add a frame to window
        frame1.pack()

        Label(frame1,
            text = "Enter an order: ").pack(side = LEFT)
        self.order = StringVar()
        entry = Entry(frame1, textvariable = self.order,
        justify = RIGHT).pack(side = LEFT)
        Button(frame1, text = "Display Sierpinski Triangle",
            command = self.display).pack(side = LEFT)

        window.mainloop() # Create an event loop

    def display(self):
        self.canvas.delete("line")
        p1 = [self.width / 2, 10]
        p2 = [10, self.height - 10]
        p3 = [self.width - 10, self.height - 10]
        self.displayTriangles(int(self.order.get()), p1, p2, p3)

    def displayTriangles(self, order, p1, p2, p3):
        if order == 0: # Base condition
            # Draw a triangle to connect three points
            self.drawLine(p1, p2)
            self.drawLine(p2, p3)
            self.drawLine(p3, p1)
        else:
            # Get the midpoint of each triangle's edge
            p12 = self.midpoint(p1, p2)
            p23 = self.midpoint(p2, p3)
            p31 = self.midpoint(p3, p1)

            # Recursively display three triangles
            self.displayTriangles(order - 1, p1, p12, p31)
            self.displayTriangles(order - 1, p12, p2, p23)
            self.displayTriangles(order - 1, p31, p23, p3)

    def drawLine(self, p1, p2):
        self.canvas.create_line(
            p1[0], p1[1], p2[0], p2[1], tags = "line")

        # Return the midpoint between two points
    def midpoint(self, p1, p2):
        p = 2 * [0]
        p[0] = (p1[0] + p2[0]) / 2
        p[1] = (p1[1] + p2[1]) / 2
        return p
    
SierpinskiTriangle() # Create GUI




# 2 koch_snowflake.py
from tkinter import *
import math

class KochSnowflake:
    def __init__(self):
        # Create window
        window = Tk()
        window.title("Koch Snowflake")

        self.width = 400
        self.height = 400
        self.canvas = Canvas(window, width=self.width, height=self.height)
        self.canvas.pack()

        # Frame for input
        frame1 = Frame(window)
        frame1.pack()

        Label(frame1, text="Enter an order: ").pack(side=LEFT)
        self.order = StringVar()
        Entry(frame1, textvariable=self.order, justify=RIGHT).pack(side=LEFT)
        Button(frame1, text="Display Koch Snowflake", command=self.display).pack(side=LEFT)

        window.mainloop()

    def display(self):
        self.canvas.delete("line")
        # Define an equilateral triangle as starting points
        size = 300
        height = size * math.sqrt(3) / 2
        p1 = [50, self.height - 50]
        p2 = [50 + size, self.height - 50]
        p3 = [50 + size / 2, self.height - 50 - height]

        # Draw three sides recursively
        order = int(self.order.get())
        self.drawKoch(order, p1, p2)
        self.drawKoch(order, p2, p3)
        self.drawKoch(order, p3, p1)

    def drawKoch(self, order, p1, p2):
        if order == 0:
            # Base case: draw line segment
            self.canvas.create_line(p1[0], p1[1], p2[0], p2[1], tags="line")
        else:
            # Divide line into thirds
            dx = (p2[0] - p1[0]) / 3
            dy = (p2[1] - p1[1]) / 3

            # Points dividing the line into 3 segments
            pa = [p1[0] + dx, p1[1] + dy]
            pb = [p1[0] + 2*dx, p1[1] + 2*dy]

            # Calculate the peak point to form the "bump"
            angle = math.radians(60)  # 60 degrees for equilateral triangle
            px = pa[0] + math.cos(angle) * (pb[0] - pa[0]) - math.sin(angle) * (pb[1] - pa[1])
            py = pa[1] + math.sin(angle) * (pb[0] - pa[0]) + math.cos(angle) * (pb[1] - pa[1])
            pc = [px, py]

            # Recursively draw four smaller segments
            self.drawKoch(order - 1, p1, pa)
            self.drawKoch(order - 1, pa, pc)
            self.drawKoch(order - 1, pc, pb)
            self.drawKoch(order - 1, pb, p2)

# Run the GUI
KochSnowflake()