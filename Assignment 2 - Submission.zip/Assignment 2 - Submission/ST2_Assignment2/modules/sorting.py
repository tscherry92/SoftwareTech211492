import pygame
import random
import sys


# =====================================================
# ARRAY GENERATION
# =====================================================

def generate_array(size=30):
    arr = []
    for _ in range(size):
        value = random.randint(20, 220)
        color = [random.randint(50, 255) for _ in range(3)]
        arr.append([value, color])
    return arr


# =====================================================
# DRAW TEXT
# =====================================================

def draw_text(screen, text, x, y, size=28, color=(0, 0, 0)):
    font = pygame.font.SysFont(None, size)
    img = font.render(text, True, color)
    screen.blit(img, (x, y))


# =====================================================
# DRAW ARRAY BARS
# =====================================================

def draw_array(screen, arr, highlight=[]):
    screen_width = screen.get_width()

    bar_width = 20
    total_width = len(arr) * bar_width
    start_x = (screen_width - total_width) // 2

    for idx, (val, color) in enumerate(arr):
        x = start_x + idx * bar_width
        y = 520 - val

        pygame.draw.rect(screen, color, (x, y, bar_width - 2, val))

        if idx in highlight:
            pygame.draw.rect(screen, (0, 0, 0), (x, y, bar_width - 2, val), 3)


# =====================================================
# DRAW MERGE RANGE BRACKET
# =====================================================

def draw_range_bracket(screen, left, right, arr_len):
    screen_width = screen.get_width()

    bar_width = 20
    total_width = arr_len * bar_width
    start_x = (screen_width - total_width) // 2

    y = 540  # just below bars

    x1 = start_x + left * bar_width
    x2 = start_x + (right + 1) * bar_width - 2

    # horizontal line
    pygame.draw.line(screen, (0, 0, 0), (x1, y), (x2, y), 3)

    # vertical ends
    pygame.draw.line(screen, (0, 0, 0), (x1, y), (x1, y - 10), 3)
    pygame.draw.line(screen, (0, 0, 0), (x2, y), (x2, y - 10), 3)


# =====================================================
# SORTING MODULE
# =====================================================

def sorting_module(screen):

    pygame.font.init()
    clock = pygame.time.Clock()

    arr = generate_array()

    current_sort = "BUBBLE"
    sorting = False
    delay = 200

    bubble_j = 0
    bubble_n = len(arr)

    selection_i = 0
    selection_j = 1
    min_index = 0

    merge_steps = []
    merge_index = 0
    merge_highlight = []
    merge_range = (0, len(arr) - 1)   # 👈 NEW

    running = True


    # =====================================================
    # MERGE SORT STEPS
    # =====================================================

    def merge_sort_steps(data):

        steps = []
        arr_copy = [item[:] for item in data]

        def merge_sort(arr, left, right):

            if left >= right:
                return

            mid = (left + right) // 2

            merge_sort(arr, left, mid)
            merge_sort(arr, mid + 1, right)

            merge(arr, left, mid, right)

        def merge(arr, left, mid, right):

            left_part = arr[left:mid + 1]
            right_part = arr[mid + 1:right + 1]

            i = 0
            j = 0
            k = left

            while i < len(left_part) and j < len(right_part):

                if left_part[i][0] <= right_part[j][0]:
                    arr[k] = left_part[i]
                    i += 1
                else:
                    arr[k] = right_part[j]
                    j += 1

                steps.append((
                    [item[:] for item in arr],
                    [k, left + i, mid + 1 + j],
                    (left, right)   # 👈 NEW: track range
                ))

                k += 1

            while i < len(left_part):
                arr[k] = left_part[i]
                i += 1
                k += 1
                steps.append(([item[:] for item in arr], [k], (left, right)))

            while j < len(right_part):
                arr[k] = right_part[j]
                j += 1
                k += 1
                steps.append(([item[:] for item in arr], [k], (left, right)))

        merge_sort(arr_copy, 0, len(arr_copy) - 1)

        return steps


    # =====================================================
    # RESET
    # =====================================================

    def reset_array():
        nonlocal arr, sorting
        nonlocal bubble_j, bubble_n
        nonlocal selection_i, selection_j, min_index
        nonlocal merge_steps, merge_index, merge_highlight, merge_range

        arr = generate_array()
        sorting = False

        bubble_j = 0
        bubble_n = len(arr)

        selection_i = 0
        selection_j = 1
        min_index = 0

        merge_steps = []
        merge_index = 0
        merge_highlight = []
        merge_range = (0, len(arr) - 1)


    # =====================================================
    # MAIN LOOP
    # =====================================================

    while running:

        screen.fill((255, 255, 255))

        W = screen.get_width()
        cx = W // 2

        title = pygame.font.SysFont(None, 60).render(
            "Sorting Visualizer", True, (0, 0, 0)
        )
        screen.blit(title, (cx - title.get_width() // 2, 10))

        current = pygame.font.SysFont(None, 30).render(
            f"Current Sort: {current_sort}", True, (100, 100, 100)
        )
        screen.blit(current, (cx - current.get_width() // 2, 70))

        # buttons
        modes = ["BUBBLE", "SELECTION", "MERGE"]
        mode_buttons = []

        bw, bh = 170, 45
        start_x = cx - (len(modes) * (bw + 20)) // 2

        for i, mode in enumerate(modes):
            rect = pygame.Rect(start_x + i * (bw + 20), 120, bw, bh)
            pygame.draw.rect(screen, (150, 150, 220), rect)
            draw_text(screen, mode, rect.x + 30, rect.y + 10, 30)
            mode_buttons.append((rect, mode))

        info = "SPACE=start | R=reset | UP=faster | DOWN=slower | ESC=back"
        info_surface = pygame.font.SysFont(None, 28).render(info, True, (0, 0, 0))
        screen.blit(info_surface, (cx - info_surface.get_width() // 2, 190))


        # =====================================================
        # HIGHLIGHT
        # =====================================================

        highlight = []

        if current_sort == "BUBBLE":
            highlight = [bubble_j, bubble_j + 1]

        elif current_sort == "SELECTION":
            highlight = [selection_i, selection_j, min_index]

        elif current_sort == "MERGE":
            highlight = merge_highlight

        draw_array(screen, arr, highlight)


        # 👇 DRAW MERGE RANGE BRACKET
        if current_sort == "MERGE" and merge_steps:
            draw_range_bracket(screen, merge_range[0], merge_range[1], len(arr))


        # =====================================================
        # SORTING LOGIC
        # =====================================================

        if sorting:

            if current_sort == "BUBBLE":

                if bubble_j < bubble_n - 1:
                    if arr[bubble_j][0] > arr[bubble_j + 1][0]:
                        arr[bubble_j], arr[bubble_j + 1] = arr[bubble_j + 1], arr[bubble_j]

                    bubble_j += 1
                else:
                    bubble_j = 0
                    bubble_n -= 1

                if bubble_n <= 1:
                    sorting = False


            elif current_sort == "SELECTION":

                if selection_i < len(arr) - 1:

                    if selection_j < len(arr):

                        if arr[selection_j][0] < arr[min_index][0]:
                            min_index = selection_j

                        selection_j += 1

                    else:
                        arr[selection_i], arr[min_index] = arr[min_index], arr[selection_i]
                        selection_i += 1
                        min_index = selection_i
                        selection_j = selection_i + 1

                else:
                    sorting = False


            elif current_sort == "MERGE":

                if not merge_steps:
                    merge_steps = merge_sort_steps(arr)
                    merge_index = 0

                if merge_index < len(merge_steps):

                    step = merge_steps[merge_index]
                    arr = [item[:] for item in step[0]]
                    merge_highlight = step[1]
                    merge_range = step[2]   # 👈 NEW

                    merge_index += 1

                else:
                    sorting = False

            pygame.time.delay(delay)


        pygame.display.flip()


        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:

                pos = pygame.mouse.get_pos()

                for rect, mode in mode_buttons:
                    if rect.collidepoint(pos):
                        current_sort = mode
                        reset_array()

            elif event.type == pygame.KEYDOWN:

                if event.key == pygame.K_ESCAPE:
                    return "MENU"

                elif event.key == pygame.K_SPACE:
                    sorting = True

                elif event.key == pygame.K_r:
                    reset_array()

                elif event.key == pygame.K_UP:
                    delay = max(10, delay - 20)

                elif event.key == pygame.K_DOWN:
                    delay = min(1000, delay + 20)

        clock.tick(60)