import pygame
import sys
import heapq
import random

pygame.init()

FONT = pygame.font.SysFont(None, 26)
BIG = pygame.font.SysFont(None, 50)

WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GREY = (200, 200, 200)
GREEN = (80, 200, 120)
RED = (220, 80, 80)
BLUE = (80, 160, 255)
PURPLE = (180, 120, 255)


# =====================================================
# MODULE
# =====================================================
def puzzles_module(screen):

    W, H = screen.get_width(), screen.get_height()
    cx = W // 2
    clock = pygame.time.Clock()

    mode = "PATHFIND"

    N = 10
    CELL = 45

    grid = [[0 for _ in range(N)] for _ in range(N)]

    start = None
    end = None

    instructions = {
        "PATHFIND": "Click: start → end → walls | SPACE: run A*",
        "EVENT": "A: add event | SPACE: pop heap | R: reset",
        "DP": "Click: toggle walls | SPACE: run DP | R: reset"
    }

    # =====================================================
    # A* (UNCHANGED LOGIC)
    # =====================================================
    frontier = []
    came_from = {}
    cost_so_far = {}
    visited = set()
    path = []
    running_search = False

    def h(a, b):
        return abs(a[0] - b[0]) + abs(a[1] - b[1])

    def start_a_star():
        nonlocal frontier, came_from, cost_so_far, running_search

        if not start or not end:
            return

        frontier = []
        heapq.heappush(frontier, (0, start))
        came_from = {start: None}
        cost_so_far = {start: 0}
        running_search = True

    def step_a_star():
        nonlocal running_search, path

        if not frontier:
            running_search = False
            return

        _, current = heapq.heappop(frontier)

        if current == end:
            running_search = False
            reconstruct_path()
            return

        visited.add(current)

        x, y = current

        for dx, dy in [(1,0),(-1,0),(0,1),(0,-1)]:
            nx, ny = x + dx, y + dy

            if 0 <= nx < N and 0 <= ny < N:
                if grid[ny][nx] == 1:
                    continue

                next_node = (nx, ny)
                new_cost = cost_so_far[current] + 1

                if next_node not in cost_so_far or new_cost < cost_so_far[next_node]:
                    cost_so_far[next_node] = new_cost
                    priority = new_cost + h(next_node, end)
                    heapq.heappush(frontier, (priority, next_node))
                    came_from[next_node] = current

    def reconstruct_path():
        nonlocal path
        cur = end
        path = []

        while cur in came_from:
            path.append(cur)
            cur = came_from[cur]

        path.reverse()

    # =====================================================
    # EVENT HEAP
    # =====================================================
    event_heap = []
    event_log = []
    event_id = 1

    def add_event():
        nonlocal event_id
        heapq.heappush(event_heap, (random.randint(1, 9), random.randint(1, 50), f"E{event_id}"))
        event_id += 1

    def step_event():
        if event_heap:
            event_log.append(heapq.heappop(event_heap))

    def reset_event():
        nonlocal event_heap, event_log, event_id
        event_heap = []
        event_log = []
        event_id = 1

    # =====================================================
    # DP (NO PATH TRACKING ANYMORE)
    # =====================================================
    dp = [[0 for _ in range(N)] for _ in range(N)]
    dp_queue = []
    dp_running = False
    dp_timer = 0
    dp_delay = 0.000001

    def start_dp():
        nonlocal dp_queue, dp_running, dp, dp_timer

        dp = [[0 for _ in range(N)] for _ in range(N)]
        dp_queue = [(0, 0)]
        dp_running = True
        dp_timer = 0

    def step_dp():
        nonlocal dp_running, dp_queue, dp_timer

        if not dp_queue:
            dp_running = False
            return

        x, y = dp_queue.pop(0)

        if grid[y][x] == 1:
            return

        if x == 0 and y == 0:
            dp[y][x] = 1
        else:
            dp[y][x] = (dp[y][x-1] if x > 0 else 0) + (dp[y-1][x] if y > 0 else 0)

        if x + 1 < N:
            dp_queue.append((x+1, y))
        if y + 1 < N:
            dp_queue.append((x, y+1))

    # =====================================================
    # RESET
    # =====================================================
    def reset_all():
        nonlocal grid, start, end, visited, path
        nonlocal frontier, came_from, cost_so_far
        nonlocal dp, dp_queue, dp_running

        grid = [[0 for _ in range(N)] for _ in range(N)]
        start = None
        end = None

        visited = set()
        path = []

        frontier = []
        came_from = {}
        cost_so_far = {}

        reset_event()

        dp = [[0 for _ in range(N)] for _ in range(N)]
        dp_queue = []
        dp_running = False

    # =====================================================
    # DRAW
    # =====================================================
    def draw_text(text, x, y, size=26, color=BLACK):
        font = pygame.font.SysFont(None, size)
        screen.blit(font.render(text, True, color), (x, y))

    running = True

    while running:

        screen.fill(WHITE)

        title = BIG.render("Puzzle Challenges", True, BLACK)
        screen.blit(title, (cx - title.get_width() // 2, 5))

        subtitle = FONT.render(f"Mode: {mode}", True, (120,120,120))
        screen.blit(subtitle, (cx - subtitle.get_width() // 2, 60))

        draw_text(instructions[mode], cx - 300, 90)

        modes = ["PATHFIND", "EVENT", "DP"]
        buttons = []

        bw, bh = 160, 40
        start_x = cx - (len(modes) * (bw + 20)) // 2

        for i, m in enumerate(modes):
            r = pygame.Rect(start_x + i*(bw+20), 120, bw, bh)
            pygame.draw.rect(screen, GREEN if mode == m else GREY, r)
            draw_text(m, r.x + 25, r.y + 8)
            buttons.append((r, m))

        # =====================================================
        # PATHFIND
        # =====================================================
        if mode == "PATHFIND":

            offset_x = cx - (N * CELL) // 2
            offset_y = 200

            if running_search:
                step_a_star()

            for y in range(N):
                for x in range(N):

                    r = pygame.Rect(offset_x + x*CELL, offset_y + y*CELL, CELL, CELL)

                    color = WHITE
                    if grid[y][x] == 1:
                        color = BLACK
                    if (x,y) == start:
                        color = GREEN
                    if (x,y) == end:
                        color = RED
                    if (x,y) in visited:
                        color = BLUE
                    if (x,y) in path:
                        color = PURPLE

                    pygame.draw.rect(screen, color, r)
                    pygame.draw.rect(screen, GREY, r, 1)

        # =====================================================
        # EVENT
        # =====================================================
        elif mode == "EVENT":

            y0 = 200

            for i, (p,t,name) in enumerate(event_heap):
                pygame.draw.rect(screen, BLUE, (cx - 250, y0 + i*40, 220, 30))
                draw_text(f"{name} P:{p}", cx - 240, y0 + i*40 + 5)

            for i, (p,t,name) in enumerate(event_log):
                pygame.draw.rect(screen, GREY, (cx + 120, y0 + i*40, 220, 30))
                draw_text(name, cx + 130, y0 + i*40 + 5)

        # =====================================================
        # DP (NO PATH DISPLAY)
        # =====================================================
        elif mode == "DP":

            offset_x = cx - (N * CELL) // 2
            offset_y = 200

            if dp_running:
                dp_timer += 1
                if dp_timer > dp_delay:
                    step_dp()
                    dp_timer = 0

            for y in range(N):
                for x in range(N):

                    r = pygame.Rect(offset_x + x*CELL, offset_y + y*CELL, CELL, CELL)

                    color = WHITE
                    if grid[y][x] == 1:
                        color = BLACK

                    pygame.draw.rect(screen, color, r)
                    pygame.draw.rect(screen, GREY, r, 1)

                    draw_text(str(dp[y][x]), r.x+10, r.y+10, 20)

        # =====================================================
        # INPUT
        # =====================================================
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_ESCAPE:
                    return "MENU"

                if event.key == pygame.K_r:
                    reset_all()

                if event.key == pygame.K_SPACE:

                    if mode == "PATHFIND":
                        if start and end:
                            start_a_star()

                    elif mode == "EVENT":
                        step_event()

                    elif mode == "DP":
                        if not dp_running:
                            start_dp()

                if event.key == pygame.K_a and mode == "EVENT":
                    add_event()

            if event.type == pygame.MOUSEBUTTONDOWN:

                pos = pygame.mouse.get_pos()

                for r,m in buttons:
                    if r.collidepoint(pos):
                        mode = m

                ox = cx - (N*CELL)//2
                oy = 200

                x = (pos[0] - ox)//CELL
                y = (pos[1] - oy)//CELL

                if 0 <= x < N and 0 <= y < N:

                    if mode == "PATHFIND":
                        if not start:
                            start = (x,y)
                        elif not end:
                            end = (x,y)
                        else:
                            grid[y][x] = 1 - grid[y][x]

                    elif mode == "DP":
                        grid[y][x] = 1 - grid[y][x]

        pygame.display.flip()
        clock.tick(60)