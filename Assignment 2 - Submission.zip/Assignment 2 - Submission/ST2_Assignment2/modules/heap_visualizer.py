import pygame
import math

pygame.font.init()

FONT = pygame.font.SysFont(None, 28)
BIG = pygame.font.SysFont(None, 60)

WHITE = (255, 255, 255)
BLACK = (20, 20, 20)
BLUE = (70, 130, 180)
RED = (200, 60, 60)
GREEN = (60, 180, 90)
GREY = (200, 200, 200)


# =====================================================
# STATE
# =====================================================
heap = []
steps = []
step_index = 0
animating = False

user_text = ""

frame_counter = 0
STEP_DELAY = 18


# =====================================================
# HELPERS
# =====================================================
def record():
    steps.append(heap.copy())


def current():
    if steps:
        return steps[step_index]
    return heap


def reset():
    global heap, steps, step_index, animating, user_text, frame_counter
    heap = []
    steps = []
    step_index = 0
    animating = False
    user_text = ""
    frame_counter = 0


# =====================================================
# INSERT (MAX HEAP)
# =====================================================
def insert(value):
    global heap, steps, step_index, animating

    steps = []
    heap.append(value)
    record()

    i = len(heap) - 1

    while i > 0:
        parent = (i - 1) // 2

        if heap[i] > heap[parent]:
            heap[i], heap[parent] = heap[parent], heap[i]
            i = parent
            record()
        else:
            break

    step_index = 0
    animating = len(steps) > 1


# =====================================================
# DELETE MAX
# =====================================================
def delete_max():
    global heap, steps, step_index, animating

    if not heap:
        return

    steps = []

    heap[0] = heap[-1]
    heap.pop()
    record()

    i = 0

    while True:
        left = 2 * i + 1
        right = 2 * i + 2
        largest = i

        if left < len(heap) and heap[left] > heap[largest]:
            largest = left
        if right < len(heap) and heap[right] > heap[largest]:
            largest = right

        if largest != i:
            heap[i], heap[largest] = heap[largest], heap[i]
            i = largest
            record()
        else:
            break

    step_index = 0
    animating = len(steps) > 1


# =====================================================
# ANIMATION ENGINE
# =====================================================
def update_animation():
    global step_index, animating, frame_counter

    if not animating:
        return

    frame_counter += 1

    if frame_counter < STEP_DELAY:
        return

    frame_counter = 0
    step_index += 1

    if step_index >= len(steps) - 1:
        step_index = len(steps) - 1
        animating = False


# =====================================================
# DRAW HEAP (CENTERED LIKE GRAPH MODULE)
# =====================================================
def draw_heap(screen, h, cx, offset_y):
    if not h:
        return

    for i, val in enumerate(h):
        level = math.floor(math.log2(i + 1))
        pos = i - (2 ** level - 1)

        nodes = 2 ** level
        spacing = 900 // (nodes + 1)

        x = cx + (spacing * (pos + 1) - 450)
        y = offset_y + level * 80

        pygame.draw.circle(screen, BLUE, (x, y), 25)
        text = FONT.render(str(val), True, WHITE)
        screen.blit(text, text.get_rect(center=(x, y)))

        # parent lines
        if i != 0:
            parent = (i - 1) // 2
            plevel = math.floor(math.log2(parent + 1))
            ppos = parent - (2 ** plevel - 1)

            pnodes = 2 ** plevel
            pspacing = 900 // (pnodes + 1)

            px = cx + (pspacing * (ppos + 1) - 450)
            py = offset_y + plevel * 80

            pygame.draw.line(screen, BLACK, (px, py), (x, y), 2)


# =====================================================
# MODULE ENTRY POINT (GRAPH STYLE UI)
# =====================================================
def heap_module(screen):
    global user_text

    clock = pygame.time.Clock()
    running = True

    while running:
        screen.fill(WHITE)

        W = screen.get_width()
        cx = W // 2

        # =====================================================
        # TITLE
        # =====================================================
        title = BIG.render("Heap Visualiser (Max Heap)", True, BLACK)
        screen.blit(title, (cx - title.get_width() // 2, 10))

        sub = pygame.font.SysFont(None, 30).render(
            f"Status: {'Animating' if animating else 'Ready'}",
            True,
            (120, 120, 120)
        )
        screen.blit(sub, (cx - sub.get_width() // 2, 70))

        # =====================================================
        # INPUT BOX
        # =====================================================
        input_box = pygame.Rect(cx - 100, 110, 200, 40)
        pygame.draw.rect(screen, GREY, input_box)

        txt = FONT.render(user_text, True, BLACK)
        screen.blit(txt, (input_box.x + 10, input_box.y + 8))

        # =====================================================
        # INSTRUCTIONS
        # =====================================================
        info = FONT.render(
            "I=Insert | D=Delete Max | ESC=Back",
            True,
            BLACK
        )
        screen.blit(info, (cx - info.get_width() // 2, 170))

        # =====================================================
        # UPDATE ANIMATION
        # =====================================================
        update_animation()

        # =====================================================
        # DRAW HEAP
        # =====================================================
        offset_y = 260
        draw_heap(screen, current(), cx, offset_y)

        pygame.display.flip()

        # =====================================================
        # EVENTS
        # =====================================================
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            if event.type == pygame.KEYDOWN:

                # EXIT
                if event.key == pygame.K_ESCAPE:
                    reset()
                    running = False

                # INSERT
                elif event.key == pygame.K_i and not animating:
                    if user_text.isdigit():
                        insert(int(user_text))
                    user_text = ""

                # DELETE MAX
                elif event.key == pygame.K_d and not animating:
                    delete_max()
                    user_text = ""

                # BACKSPACE
                elif event.key == pygame.K_BACKSPACE:
                    user_text = user_text[:-1]

                # NUMBER INPUT
                else:
                    if event.unicode.isdigit():
                        user_text += event.unicode

        clock.tick(60)