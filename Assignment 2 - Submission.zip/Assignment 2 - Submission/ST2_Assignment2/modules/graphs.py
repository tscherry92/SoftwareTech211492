import pygame
import sys


# =====================================================
# DRAW TEXT (same style as sorting module)
# =====================================================

def draw_text(screen, text, x, y, size=28, color=(0, 0, 0)):
    font = pygame.font.SysFont(None, size)
    img = font.render(text, True, color)
    screen.blit(img, (x, y))


# =====================================================
# GRAPH MODULE
# =====================================================

def graphs_module(screen):

    pygame.font.init()
    clock = pygame.time.Clock()

    # =====================================================
    # GRAPH STRUCTURE
    # =====================================================
    graph = {
            0: [1, 2],

            1: [3, 4],
            2: [5, 6],

            3: [7, 8],
            4: [9, 10],
            5: [11, 12],
            6: [],

            7: [],
            8: [],
            9: [],
            10: [],
            11: [],
            12: []
    }

    # Relative layout (tree shape)
    base_positions = {
        0: (0, 0),

        1: (-180, 120),
        2: (180, 120),

        3: (-260, 240),
        4: (-100, 240),
        5: (100, 240),
        6: (260, 240),

        7: (-300, 380),
        8: (-200, 380),
        9: (-120, 380),
        10: (-20, 380),
        11: (120, 380),
        12: (220, 380)
    }

    # =====================================================
    # STATE
    # =====================================================
    mode = "BFS"

    visited = set()
    frontier = [0]
    current = None

    running = True

    # =====================================================
    # RESET FUNCTION
    # =====================================================
    def reset():
        nonlocal visited, frontier, current
        visited = set()
        frontier = [0]
        current = None

    # =====================================================
    # MAIN LOOP
    # =====================================================
    while running:

        screen.fill((255, 255, 255))

        W = screen.get_width()
        cx = W // 2

        # =====================================================
        # TITLE
        # =====================================================
        title = pygame.font.SysFont(None, 60).render(
            "Graph Traversal Visualizer", True, (0, 0, 0)
        )
        screen.blit(title, (cx - title.get_width() // 2, 10))

        sub = pygame.font.SysFont(None, 30).render(
            f"Mode: {mode}", True, (100, 100, 100)
        )
        screen.blit(sub, (cx - sub.get_width() // 2, 70))

        # =====================================================
        # MODE BUTTONS (BFS / DFS)
        # =====================================================
        modes = ["BFS", "DFS"]
        mode_buttons = []

        bw, bh = 150, 45
        start_x = cx - (len(modes) * (bw + 20)) // 2

        for i, m in enumerate(modes):

            rect = pygame.Rect(start_x + i * (bw + 20), 120, bw, bh)

            color = (120, 200, 120) if mode == m else (150, 150, 220)

            pygame.draw.rect(screen, color, rect)
            draw_text(screen, m, rect.x + 45, rect.y + 10, 30)

            mode_buttons.append((rect, m))

        # =====================================================
        # INSTRUCTIONS
        # =====================================================
        info = "SPACE=step | R=reset | ESC=back"
        info_surface = pygame.font.SysFont(None, 28).render(info, True, (0, 0, 0))
        screen.blit(info_surface, (cx - info_surface.get_width() // 2, 190))

        # =====================================================
        # GRAPH CENTERING
        # =====================================================
        offset_y = 260

        # =====================================================
        # DRAW EDGES
        # =====================================================
        for node, neighbors in graph.items():
            for n in neighbors:

                x1 = cx + base_positions[node][0]
                y1 = offset_y + base_positions[node][1]

                x2 = cx + base_positions[n][0]
                y2 = offset_y + base_positions[n][1]

                pygame.draw.line(screen, (180, 180, 180), (x1, y1), (x2, y2), 2)

        # =====================================================
        # EVENT HANDLING
        # =====================================================
        for event in pygame.event.get():

            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:

                if event.key == pygame.K_ESCAPE:
                    return "MENU"

                if event.key == pygame.K_r:
                    reset()

                # STEP THROUGH BFS / DFS
                if event.key == pygame.K_SPACE:

                    if frontier:

                        if mode == "BFS":
                            current = frontier.pop(0)
                        else:
                            current = frontier.pop()

                        if current not in visited:
                            visited.add(current)

                            for n in graph[current]:
                                if n not in visited:
                                    frontier.append(n)

            # MODE SWITCH (BUTTONS)
            if event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()

                for rect, m in mode_buttons:
                    if rect.collidepoint(pos):
                        mode = m
                        reset()

        # =====================================================
        # DRAW NODES
        # =====================================================
        for node, pos in base_positions.items():

            x = cx + pos[0]
            y = offset_y + pos[1]

            color = (200, 200, 200)

            if node == current:
                color = (255, 100, 100)   # current
            elif node in visited:
                color = (100, 200, 100)   # visited
            elif node in frontier:
                color = (255, 200, 100)   # frontier

            pygame.draw.circle(screen, color, (x, y), 25)
            pygame.draw.circle(screen, (0, 0, 0), (x, y), 25, 2)

            label = pygame.font.SysFont(None, 28).render(str(node), True, (0, 0, 0))
            screen.blit(label, (x - 8, y - 10))

        pygame.display.flip()
        clock.tick(60)