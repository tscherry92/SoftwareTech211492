import pygame
import sys
import random

# =====================================================
# DATA STRUCTURES
# =====================================================

class ListNode:
    def __init__(self, value):
        self.value = value
        self.next = None


class BSTNode:
    def __init__(self, value):
        self.value = value
        self.left = None
        self.right = None


# =====================================================
# BST LOGIC
# =====================================================

def bst_insert(root, value):
    if not root:
        return BSTNode(value)

    if value < root.value:
        root.left = bst_insert(root.left, value)
    else:
        root.right = bst_insert(root.right, value)

    return root


def bst_delete(root, value):
    if not root:
        return None

    if value < root.value:
        root.left = bst_delete(root.left, value)
    elif value > root.value:
        root.right = bst_delete(root.right, value)
    else:
        if not root.left:
            return root.right
        if not root.right:
            return root.left

        temp = root.right
        while temp.left:
            temp = temp.left

        root.value = temp.value
        root.right = bst_delete(root.right, temp.value)

    return root


# =====================================================
# LINKED LIST LOGIC
# =====================================================

def ll_insert(state):
    node = ListNode(state["queue_counter"])
    state["queue_counter"] += 1

    if not state["linked_list_head"]:
        state["linked_list_head"] = node
        return

    cur = state["linked_list_head"]
    while cur.next:
        cur = cur.next
    cur.next = node


def ll_delete(state):
    if not state["linked_list_head"]:
        return

    state["linked_list_head"] = state["linked_list_head"].next


def ll_reverse(state):
    prev = None
    cur = state["linked_list_head"]

    while cur:
        nxt = cur.next
        cur.next = prev
        prev = cur
        cur = nxt

    state["linked_list_head"] = prev


# =====================================================
# QUEUE LOGIC
# =====================================================

def enqueue(state):
    state["queue"].append(state["queue_counter"])
    state["queue_counter"] += 1


def dequeue(state):
    if state["queue"]:
        state["queue"].pop(0)


# =====================================================
# DRAW HELPERS
# =====================================================

def draw_text(screen, text, x, y, size=28):
    font = pygame.font.SysFont(None, size)
    screen.blit(font.render(text, True, (0, 0, 0)), (x, y))


def draw_bst(screen, node, x, y, spacing):
    if not node:
        return

    pygame.draw.circle(screen, (200, 255, 200), (x, y), 15)
    draw_text(screen, str(node.value), x - 8, y - 10, 25)

    if node.left:
        pygame.draw.line(screen, (0, 0, 0), (x, y), (x - spacing, y + 60), 2)
        draw_bst(screen, node.left, x - spacing, y + 60, spacing // 2)

    if node.right:
        pygame.draw.line(screen, (0, 0, 0), (x, y), (x + spacing, y + 60), 2)
        draw_bst(screen, node.right, x + spacing, y + 60, spacing // 2)


# =====================================================
# MAIN MODULE
# =====================================================

def data_structures_module(screen):

    state = {
        "stack": [],
        "queue": [],
        "linked_list_head": None,
        "bst": None,
        "queue_counter": 1,
        "current_view": "STACK",
        "bst_input": ""
    }

    running = True
    clock = pygame.time.Clock()

    while running:
        screen.fill((255, 255, 255))

        W, H = screen.get_width(), screen.get_height()
        cx = W // 2

        base_y = int(H * 0.75)
        bst_y = int(H * 0.35)

        # =====================================================
        # TITLE
        # =====================================================

        title = pygame.font.SysFont(None, 60).render("Data Structures", True, (0, 0, 0))
        screen.blit(title, (cx - title.get_width() // 2, 10))

        view = pygame.font.SysFont(None, 28).render(
            f"Current View: {state['current_view']}", True, (100, 100, 100)
        )
        screen.blit(view, (cx - view.get_width() // 2, 70))

        # =====================================================
        # DRAW CURRENT VIEW
        # =====================================================

        if state["current_view"] == "STACK":
            for i, v in enumerate(state["stack"]):
                y = base_y - i * 40
                pygame.draw.rect(screen, (100, 100, 255), (cx - 40, y, 80, 30))
                draw_text(screen, str(v), cx - 10, y + 5)

        elif state["current_view"] == "QUEUE":
            for i, v in enumerate(state["queue"]):
                y = base_y - i * 40
                pygame.draw.rect(screen, (255, 150, 100), (cx - 40, y, 80, 30))
                draw_text(screen, str(v), cx - 10, y + 5)

        elif state["current_view"] == "LINKED":
            cur = state["linked_list_head"]
            x = cx - 200
            y = base_y

            while cur:
                pygame.draw.rect(screen, (180, 180, 255), (x, y, 60, 30))
                draw_text(screen, str(cur.value), x + 20, y + 5)

                if cur.next:
                    pygame.draw.line(screen, (0, 0, 0), (x + 60, y + 15), (x + 90, y + 15), 2)

                cur = cur.next
                x += 100

        elif state["current_view"] == "BST":
            draw_bst(screen, state["bst"], cx, bst_y, 120)

            # input box
            box = pygame.Rect(cx - 120, H - 140, 240, 40)
            pygame.draw.rect(screen, (230, 230, 230), box)
            pygame.draw.rect(screen, (0, 0, 0), box, 2)

            txt = state["bst_input"] or "Enter number..."
            draw_text(screen, txt, box.x + 10, box.y + 8)

        # =====================================================
        # MODE BUTTONS
        # =====================================================

        modes = ["STACK", "QUEUE", "LINKED", "BST"]
        btns = []

        bw, bh = 140, 40
        start_x = cx - (len(modes) * (bw + 20)) // 2

        for i, m in enumerate(modes):
            r = pygame.Rect(start_x + i * (bw + 20), 120, bw, bh)
            pygame.draw.rect(screen, (150, 150, 200), r)
            draw_text(screen, m, r.x + 30, r.y + 10, 25)
            btns.append((r, m))

        # =====================================================
        # ACTION BUTTONS
        # =====================================================

        actions = []

        if state["current_view"] == "STACK":
            actions = [
                ("Push", lambda: state["stack"].append(len(state["stack"]) + 1)),
                ("Pop", lambda: state["stack"].pop() if state["stack"] else None),
            ]

        elif state["current_view"] == "QUEUE":
            actions = [
                ("Enqueue", lambda: enqueue(state)),
                ("Dequeue", lambda: dequeue(state)),
            ]

        elif state["current_view"] == "LINKED":
            actions = [
                ("Insert", lambda: ll_insert(state)),
                ("Delete", lambda: ll_delete(state)),
                ("Reverse", lambda: ll_reverse(state)),
            ]

        elif state["current_view"] == "BST":
            actions = [
                ("Insert", lambda: bst_insert_from_input(state)),
                ("Delete", lambda: bst_delete_from_input(state)),
            ]

        action_btns = []
        start = cx - len(actions) * 90

        for i, (label, func) in enumerate(actions):
            r = pygame.Rect(start + i * 180, H - 80, 150, 45)
            pygame.draw.rect(screen, (120, 180, 120), r)
            draw_text(screen, label, r.x + 30, r.y + 10, 25)
            action_btns.append((r, func))

        pygame.display.flip()

        # =====================================================
        # EVENTS
        # =====================================================

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            elif event.type == pygame.MOUSEBUTTONDOWN:
                pos = pygame.mouse.get_pos()

                for r, m in btns:
                    if r.collidepoint(pos):
                        state["current_view"] = m

                for r, f in action_btns:
                    if r.collidepoint(pos):
                        f()
            elif event.type == pygame.KEYDOWN:

                # ---------------- ESC BACK TO MENU ----------------
                if event.key == pygame.K_ESCAPE:
                    return "MENU"

                if state["current_view"] == "BST":
                    if event.key == pygame.K_BACKSPACE:
                        state["bst_input"] = state["bst_input"][:-1]

                    elif event.key == pygame.K_RETURN:
                        bst_insert_from_input(state)

                    else:
                        if event.unicode.isdigit():
                            state["bst_input"] += event.unicode

        clock.tick(60)


# =====================================================
# BST INPUT HELPERS
# =====================================================

def bst_insert_from_input(state):
    if state["bst_input"].isdigit():
        state["bst"] = bst_insert(state["bst"], int(state["bst_input"]))
    state["bst_input"] = ""


def bst_delete_from_input(state):
    if state["bst_input"].isdigit():
        state["bst"] = bst_delete(state["bst"], int(state["bst_input"]))
    state["bst_input"] = ""


print("data_structures module loaded")