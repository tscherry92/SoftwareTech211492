import pygame
import sys

# Import modules
from modules.data_structures import data_structures_module
from modules.sorting import sorting_module
from modules.graphs import graphs_module
from modules.heap_visualizer import heap_module
from modules.puzzles import puzzles_module

# Import utils
from utils.ui import draw_text
from utils.constants import WIDTH, HEIGHT

pygame.init()

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("DSA Explorer")

clock = pygame.time.Clock()


def main_menu():
    screen.fill((200, 200, 250))

    # Title 
    title_font = pygame.font.SysFont(None, 60)
    title = title_font.render("DSA Explorer", True, (0, 0, 0))
    screen.blit(title, (WIDTH // 2 - title.get_width() // 2, 50))

    # Button settings
    button_width = 240
    button_height = 55
    spacing = 20

    start_y = 150

    labels = [
        "Data Structures",
        "Sorting",
        "Graphs",
        "Heap",
        "Puzzles"
    ]

    buttons = {}

    # Create + draw centered buttons
    for i, text in enumerate(labels):
        x = WIDTH // 2 - button_width // 2
        y = start_y + i * (button_height + spacing)

        rect = pygame.Rect(x, y, button_width, button_height)
        buttons[text] = rect

        pygame.draw.rect(screen, (150, 150, 200), rect, border_radius=8)

        draw_text(screen, text, (x + 20, y + 15))

    pygame.display.flip()
    return buttons


# MAIN LOOP
def main():
    running = True
    current_module = None

    buttons = main_menu()

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN:
                if current_module is None:
                    pos = pygame.mouse.get_pos()

                    for name, rect in buttons.items():
                        if rect.collidepoint(pos):
                            current_module = name

        # NAVIGATION
        if current_module is None:
            buttons = main_menu()

        else:
            if current_module == 'Data Structures':
                data_structures_module(screen)

            elif current_module == 'Sorting':
                sorting_module(screen)

            elif current_module == 'Graphs':
                graphs_module(screen)

            elif current_module == 'Heap':
                heap_module(screen)

            elif current_module == 'Puzzles':
                puzzles_module(screen)

            # Return to menu after module exits
            current_module = None

        clock.tick(60)

    pygame.quit()
    sys.exit()


# RUN APP
if __name__ == "__main__":
    main()