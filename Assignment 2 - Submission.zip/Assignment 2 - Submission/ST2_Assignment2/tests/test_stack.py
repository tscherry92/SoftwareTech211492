import unittest


class TestStack(unittest.TestCase):

    def test_push(self):
        stack = []

        stack.append(10)
        stack.append(20)

        self.assertEqual(stack[-1], 20)
        self.assertEqual(len(stack), 2)

    def test_pop(self):
        stack = [1, 2, 3]

        top = stack.pop()

        self.assertEqual(top, 3)
        self.assertEqual(stack, [1, 2])

    def test_lifo_behavior(self):
        stack = []

        stack.append('A')
        stack.append('B')
        stack.append('C')

        self.assertEqual(stack.pop(), 'C')
        self.assertEqual(stack.pop(), 'B')
        self.assertEqual(stack.pop(), 'A')

    def test_empty_stack(self):
        stack = []
        self.assertEqual(len(stack), 0)

    def test_pop_empty_stack(self):
        stack = []

        with self.assertRaises(IndexError):
            stack.pop()


if __name__ == "__main__":
    unittest.main()