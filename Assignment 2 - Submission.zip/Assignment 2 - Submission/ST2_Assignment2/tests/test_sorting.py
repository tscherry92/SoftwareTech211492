import unittest

def bubble_sort(arr):
    arr = arr.copy()
    n = len(arr)

    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]

    return arr


class TestSorting(unittest.TestCase):

    def test_bubble_sort_basic(self):
        arr = [5, 3, 8, 1]
        sorted_arr = bubble_sort(arr)
        self.assertEqual(sorted_arr, [1, 3, 5, 8])

    def test_bubble_sort_empty(self):
        self.assertEqual(bubble_sort([]), [])

    def test_bubble_sort_single(self):
        self.assertEqual(bubble_sort([1]), [1])

    def test_bubble_sort_sorted(self):
        self.assertEqual(bubble_sort([1,2,3]), [1,2,3])


if __name__ == "__main__":
    unittest.main()