import unittest
from collections import deque


def bfs(graph, start):
    visited = []
    queue = deque([start])

    while queue:
        node = queue.popleft()
        if node not in visited:
            visited.append(node)
            for neighbour in graph[node]:
                queue.append(neighbour)

    return visited


class TestGraphs(unittest.TestCase):

    def test_bfs(self):
        graph = {
            0: [1, 2],
            1: [3],
            2: [3],
            3: []
        }

        result = bfs(graph, 0)
        self.assertEqual(result, [0, 1, 2, 3])

    def test_bfs_single_node(self):
        graph = {0: []}
        self.assertEqual(bfs(graph, 0), [0])


if __name__ == "__main__":
    unittest.main()