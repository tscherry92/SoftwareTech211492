import pygame

pygame.font.init()
FONT = pygame.font.SysFont(None, 36)

def draw_text(screen, text, pos):
    txt = FONT.render(text, True, (0, 0, 0))
    screen.blit(txt, pos)