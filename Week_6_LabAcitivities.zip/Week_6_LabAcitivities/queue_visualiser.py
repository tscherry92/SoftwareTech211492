import tkinter as tk
from tkinter import messagebox
from collections import deque

NODE_WIDTH = 80
NODE_HEIGHT = 40
VERTICAL_GAP = 10
CANVAS_WIDTH = 300
CANVAS_HEIGHT = 500

# Queue operations using deque
def queue_enqueue(queue, values):
    for val in values:
        queue.append(val)

def queue_dequeue(queue, count):
    for _ in range(count):
        if queue:
            queue.popleft()

def queue_peek(queue):
    return queue[0] if queue else None

class QueueVisualizer:
    def __init__(self, root):
        self.root = root
        self.root.title("Queue Visualizer")

        self.queue = deque()

        self.canvas = tk.Canvas(root, width=CANVAS_WIDTH, height=CANVAS_HEIGHT, bg='white')
        self.canvas.pack(pady=20)

        control_frame = tk.Frame(root)
        control_frame.pack()

        # Enqueue controls
        tk.Label(control_frame, text="Enqueue Value:").grid(row=0, column=0)
        self.enqueue_entry = tk.Entry(control_frame, width=10)
        self.enqueue_entry.grid(row=0, column=1)

        enqueue_btn = tk.Button(control_frame, text="Enqueue", command=self.enqueue_value)
        enqueue_btn.grid(row=0, column=2, padx=5)

        dequeue_btn = tk.Button(control_frame, text="Dequeue", command=self.dequeue_value)
        dequeue_btn.grid(row=1, column=2, pady=5)

        self.status_label = tk.Label(root, text="", fg="blue", font=("Arial", 12))
        self.status_label.pack(pady=5)

        self.draw_queue()

    def draw_node(self, x, y, data, highlight=False):
        fill_color = "lightgreen" if not highlight else "yellow"
        self.canvas.create_rectangle(x, y, x + NODE_WIDTH, y + NODE_HEIGHT, fill=fill_color, outline="black", width=2)
        self.canvas.create_text(x + NODE_WIDTH/2, y + NODE_HEIGHT/2, text=str(data), font=("Arial", 16))

    def draw_queue(self, highlight_index=None):
        self.canvas.delete("all")
        x = (CANVAS_WIDTH - NODE_WIDTH) // 2
        y = CANVAS_HEIGHT - NODE_HEIGHT - 10
        for i, val in enumerate(reversed(self.queue)):
            highlight = (highlight_index is not None and i == highlight_index)
            self.draw_node(x, y, val, highlight)
            y -= NODE_HEIGHT + VERTICAL_GAP
        # Draw labels for Front and Rear
        if self.queue:
            self.canvas.create_text(x + NODE_WIDTH + 50, CANVAS_HEIGHT - NODE_HEIGHT - 10, text="Rear", font=("Arial", 12), fill="red")
            self.canvas.create_text(x + NODE_WIDTH + 50, CANVAS_HEIGHT - (len(self.queue)) * (NODE_HEIGHT + VERTICAL_GAP), text="Front", font=("Arial", 12), fill="blue")

    def enqueue_value(self):
        try:
            val = int(self.enqueue_entry.get())
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter an integer value to enqueue.")
            return
        queue_enqueue(self.queue, [val])
        self.enqueue_entry.delete(0, tk.END)
        self.status_label.config(text=f"Enqueued {val} to queue")
        self.draw_queue()

    def dequeue_value(self):
        if not self.queue:
            messagebox.showinfo("Empty Queue", "Queue is empty. Cannot dequeue.")
            return
        val = queue_peek(self.queue)
        queue_dequeue(self.queue, 1)
        self.status_label.config(text=f"Dequeued {val} from queue")
        self.draw_queue()

if __name__ == "__main__":
    root = tk.Tk()
    app = QueueVisualizer(root)

    # Optional: Pre-populate queue
    for v in []:
        queue_enqueue(app.queue, [v])
    app.draw_queue()

    root.mainloop()